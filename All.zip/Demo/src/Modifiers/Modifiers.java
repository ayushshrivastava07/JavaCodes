package Modifiers;

public class Modifiers {
private int i=1;
protected int j=2;
int k=3;
public void show() {
	System.out.println(i);
}
}
class Test1{
	public void display() {
		Modifiers mod=new Modifiers();
		System.out.println(mod.k);
	}
}
