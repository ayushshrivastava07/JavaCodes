package MultiThreading;

public class MultiThreading {
public static void main(String[] args) {
	Table obj=new Table();
	MyThread th=new MyThread(obj);
	MyThread1 th1=new MyThread1(obj);
	th.start();
	th1.start();
	try {
		th.join();
//		th.wait();
//		th.notify();
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
class MyThread extends Thread{
	Table t;
	MyThread(Table t){
		this.t=t;
	}
	public void run() {
		
		t.printTable(5);
	}
	
}
class MyThread1 extends Thread{
	Table t;
	MyThread1(Table t){
		this.t=t;
	}
	public void run() {
		t.printTable(100);
	}
	
}
class Table {
	public synchronized void printTable(int n) {
		// synchronized(this) {
		for(int i=1;i<6;i++) {
		System.out.println(n*i);
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println("Error found");
		}
		//}
	}
	}
}

