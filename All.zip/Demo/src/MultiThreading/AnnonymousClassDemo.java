package MultiThreading;

public class AnnonymousClassDemo {
public static void main(String[] args) {
	//Without anonymous class we have to do this
	B b=new B();
	b.show();
	
	//With anonymous we need not to create class only interface is required
	TestDemo t=new TestDemo() {
		public void show() {
			System.out.println("hello");
		}
	};
	t.show();
}
}

interface TestDemo{ 
	void show();
	}

//Only for non anonymous method
class B implements TestDemo{
	public void show() {
		System.out.println("hello");
	}
}
