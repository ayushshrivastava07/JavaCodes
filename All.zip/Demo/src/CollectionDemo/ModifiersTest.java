package CollectionDemo;

import Modifiers.Modifiers;


public class ModifiersTest extends Modifiers{
public void output() {
	ModifiersTest mod1=new ModifiersTest();
	System.out.println(mod1.j);
}

}
