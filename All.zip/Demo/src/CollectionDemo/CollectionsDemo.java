package CollectionDemo;


import java.util.ArrayList;
import java.util.Vector;

public class CollectionsDemo{
	public static void main(String[] args) {
		List list1=new List();
		MyThread th=new MyThread(list1);
		MyThread1 th1=new MyThread1(list1);
		th.start();
		th1.start();
		}
}
class MyThread extends Thread{
	List l;
	public MyThread(List l){
		this.l=l;
	}
	public void run() {
		l.printList();
	}
	
}

class MyThread1 extends Thread{
	List l;
	public MyThread1(List l) {
	this.l=l;
	}
	public void run() {
		l.printList();
	}
	
}

class List{
	public void printList() {
		Vector <Integer> list= new Vector<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		list.add(4);
		list.add(5);
		try {
			for(Integer x:list) {
				System.out.println(x);
				Thread.sleep(400);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}






