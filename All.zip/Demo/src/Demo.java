
public class Demo{
	public static void main(String[] args) {
		MyThread mythread=new MyThread();
		MyThread11 mythread1=new MyThread11();
		mythread.start();
		mythread1.start();
		
	}
}
class Table1{
	public void printTable(int n) {
		for(int i=1;i<=5;i++) {
			System.out.println(i*n);
			try {
				Thread.sleep(1000);
			}
			catch(Exception e) {
				System.out.println("Exception");
			}
		}
	}
}
class MyThread extends Thread{
	Table1 t=new Table1();
	public void run() {
		t.printTable(5);
	}
}
class MyThread11 extends Thread{
	Table1 t=new Table1();
	public void run() {
		t.printTable(100);
	}
}
