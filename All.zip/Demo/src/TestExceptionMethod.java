import java.io.FileNotFoundException;
import java.io.IOException;

public class TestExceptionMethod {
	public static String name="Ayush";
public static void main(String[] args) {
	name="Rakesh";
	System.out.println(name);
}
}
interface Demos{

	public void show () throws IOException;
	
}
class Demo2 implements Demos{
	
	public void show() throws FileNotFoundException {
		
	}
}
